package com.in28minutes.java.to.python.examples.set1;

public class MathBasic2 {
	
	static int sumOfTwoNumbers(int firstNumber, int secondNumber) {
		int sum = firstNumber + secondNumber;
		return sum;
	}

	public static void main(String[] args) {
		sumOfTwoNumbers(10,20);
	}
}