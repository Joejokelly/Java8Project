package com.in28minutes.java.to.python.examples.set1;

public class HelloWorld {
	public static void main(String[] args) {
		System.out.println("Hello World");
		char a = 'a';
	}
}
