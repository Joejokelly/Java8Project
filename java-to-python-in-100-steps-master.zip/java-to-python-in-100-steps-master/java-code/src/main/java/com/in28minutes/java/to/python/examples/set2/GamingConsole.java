package com.in28minutes.java.to.python.examples.set2;

public interface GamingConsole {
	public void up();
	public void down();
	public void left();
	public void right();
}

