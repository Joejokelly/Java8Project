# Course Guide



## Getting Started With Python

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code



## Conditionals and Loops

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code




## Object Oriented Programming with Python

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code



## Built-In Python Modules

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code




## Python Data Structures

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code



## Exception Handling in Python

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code



## Functional Programming

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code



## Python Tips

### Step By Step Details

### Python Shell Code

```py
```
### PyCharm Code
