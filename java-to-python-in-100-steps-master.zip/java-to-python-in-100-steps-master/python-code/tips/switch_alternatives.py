week_days = {
    0 : 'Sunday',
    1 : 'Monday',
    2 : 'Tuesday'
    # You can fill rest of the stuff
}

print(week_days.get(7,'Invalid_day'))
