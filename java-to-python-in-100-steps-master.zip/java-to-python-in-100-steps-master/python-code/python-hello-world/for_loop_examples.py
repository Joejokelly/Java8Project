for i in range(1,10):
    print(i)
    print("Done")

for i in range(1,10):
    print(i*i)

print("Test")
