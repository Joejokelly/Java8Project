# How to run this
- Choose the Project in Eclipse
- Right Click on Project and Choose Run as Maven Build
- Type in tomcat7:run and press enter

- Goto http://localhost:8080
  - use in28Minutes/dummy
  - User id/ password combination is case sensitive

