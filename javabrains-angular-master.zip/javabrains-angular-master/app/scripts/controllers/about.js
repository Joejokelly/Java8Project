'use strict';

/**
 * @ngdoc function
 * @name jb3App.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the jb3App
 */
angular.module('jb3App')
  .controller('AboutCtrl', function ($scope) {
  });
