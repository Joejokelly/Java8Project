'use strict';

/**
 * @ngdoc function
 * @name jb3App.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the jb3App
 */
angular.module('jb3App')
  .controller('MainCtrl', function ($scope) {
  });
